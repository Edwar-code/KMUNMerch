'use client'

import React, { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import { PayheroClient } from '@/lib/PayheroClient';

// Extended interfaces 
interface Address {
  street: string;
  cityId: string | null;
  countyId: string | null;
  countryId: string | null;
}

interface CartPricing {
  subtotal: number;
  formattedSubtotal: string;
  vat: number;
  formattedVAT: string;
  total: number;
  formattedTotal: string;
}

interface CartProduct {
  id: string;
  name: string;
  price: number;
  images: string[];
  slug: string;
}

interface CartItem {
  id: string;
  product: CartProduct;
  quantity: number;
  variation: string | null;
}

interface CartData {
  items: CartItem[];
  totalItems: number;
  pricing?: CartPricing;
}

interface UserData {
  id: string;
  name: string;
  email: string;
  number: string;
  countryId: string | null;
  countyId: string | null;
  cityId: string | null;
  street: string | null;
}

interface LocationData {
  id: string;
  name: string;
  type: string;
}

interface PaymentStatus {
  status: 'idle' | 'loading' | 'success' | 'error';
  message: string;
  reference?: string;
}

const CheckoutPageSkeleton = () => {
    return (
        <section className="bg-white py-8 antialiased dark:bg-gray-900 md:py-16">
            <div className="mx-auto max-w-screen-xl px-4 2xl:px-0">
                <div className="mt-6 sm:mt-8 lg:flex lg:items-start lg:gap-12 xl:gap-16 animate-pulse">
                    {/* Left Side: Delivery Details and Payment */}
                    <div className="min-w-0 flex-1 space-y-8">
                        {/* Delivery Details Skeleton */}
                        <div className="space-y-4">
                            <div className="h-8 bg-gray-300 rounded dark:bg-gray-700 w-1/3 mb-4"></div>

                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                {[1, 2, 3, 4, 5, 6].map((item) => (
                                    <div key={item} className="space-y-2">
                                        <div className="h-5 bg-gray-300 rounded dark:bg-gray-700 w-1/4 mb-2"></div>
                                        <div className="h-10 bg-gray-300 rounded dark:bg-gray-700 w-full"></div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Payment Skeleton */}
                        <div className="space-y-4">
                            <div className="h-8 bg-gray-300 rounded dark:bg-gray-700 w-1/4 mb-4"></div>

                            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                                <div className="rounded-lg border border-gray-200 bg-gray-50 p-4 dark:border-gray-700 dark:bg-gray-800 space-y-2">
                                    <div className="flex items-center">
                                        <div className="h-4 w-4 bg-gray-300 rounded-full mr-4"></div>
                                        <div className="h-6 bg-gray-300 rounded dark:bg-gray-700 w-1/2"></div>
                                    </div>
                                    <div className="h-4 bg-gray-300 rounded dark:bg-gray-700 w-1/3"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Right Side: Order Summary */}
                    <div className="mt-6 w-full space-y-6 sm:mt-8 lg:mt-0 lg:max-w-xs xl:max-w-md">
                        <div className="flow-root">
                            <div className="-my-3 divide-y divide-gray-200 dark:divide-gray-800 space-y-4">
                                {[1, 2, 3].map((item) => (
                                    <div key={item} className="flex items-center justify-between gap-4 py-3">
                                        <div className="h-6 bg-gray-300 rounded dark:bg-gray-700 w-1/3"></div>
                                        <div className="h-6 bg-gray-300 rounded dark:bg-gray-700 w-1/4"></div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Payment Status Skeleton */}
                        <div className="h-16 bg-gray-300 rounded dark:bg-gray-700 w-full"></div>

                        {/* Submit Button Skeleton */}
                        <div className="h-12 bg-gray-300 rounded-lg dark:bg-gray-700 w-full"></div>
                    </div>
                </div>
            </div>
        </section>
    );
};


const CheckoutPage = () => {
  const { data: session, status } = useSession();
  const [userData, setUserData] = useState<UserData | null>(null);
  const [cartData, setCartData] = useState<CartData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>({
    status: 'idle',
    message: ''
  });

  const [countryName, setCountryName] = useState<string | null>(null);
  const [countyName, setCountyName] = useState<string | null>(null);
  const [cityName, setCityName] = useState<string | null>(null);

  const primaryAddress = {
    street: userData?.street || '',
    cityId: userData?.cityId || null,
    countyId: userData?.countyId || null,
    countryId: userData?.countryId || null
  };

  useEffect(() => {
    const fetchLocationNames = async () => {
      try {
        if (userData?.countryId) {
          const countryResponse = await fetch(`/api/locations?id=${userData.countryId}`); 
          if (countryResponse.ok) {
            const countryData = await countryResponse.json();
            setCountryName(countryData[0]?.name || null);
          }
        }
        if (userData?.countyId) {
          const countyResponse = await fetch(`/api/locations?id=${userData.countyId}`); 
          if (countyResponse.ok) {
            const countyData = await countyResponse.json();
            setCountyName(countyData[0]?.name || null);
          }
        }
        if (userData?.cityId) {
          const cityResponse = await fetch(`/api/locations?id=${userData.cityId}`); 
          if (cityResponse.ok) {
            const cityData = await cityResponse.json();
            setCityName(cityData[0]?.name || null);
          }
        }
      } catch (error) {
        console.error("Error fetching location names:", error);
      }
    };

    if (userData) {
      fetchLocationNames();
    }
  }, [userData]);

  useEffect(() => {
    const fetchData = async () => {
      if (!session?.user?.id) return;

      try {
        const userResponse = await fetch(`/api/users?id=${session.user.id}`);
        if (!userResponse.ok) {
          throw new Error(`Failed to fetch user data: ${userResponse.status}`);
        }
        const user = await userResponse.json();
        setUserData(user);

        const cartResponse = await fetch(`/api/cart?userId=${session.user.id}`);
        if (!cartResponse.ok) {
          throw new Error(`Failed to fetch cart data: ${cartResponse.status}`);
        }
        const cart = await cartResponse.json();
        setCartData({
          items: cart.items,
          totalItems: cart.items.length,
        });
      } catch (err) {
        if (err instanceof Error) {
          setError(err.message);
        } else {
          setError('An unexpected error occurred');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [session?.user?.id]);

  const generateExternalReference = () => {
    const randomDigits = Math.floor(10000 + Math.random() * 90000);
    return `INV-${randomDigits}`;
  };

  const createOrder = async () => {
    if (!session?.user?.id || !cartData || !primaryAddress) {
      throw new Error('Missing required order information');
    }

    const orderItems = cartData.items.map(item => ({
      productId: item.product.id,
      quantity: item.quantity,
      variation: item.variation,
    }));

    const subtotal = cartData.items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    const totalAmount = subtotal + (subtotal * 0.16);

    const externalReference = generateExternalReference();

    const orderData = {
      userId: session.user.id,
      items: orderItems,
      total: totalAmount,
      countryId: primaryAddress.countryId,
      countyId: primaryAddress.countyId,
      cityId: primaryAddress.cityId,
      street: primaryAddress.street,
      paymentReference: externalReference,
    };

    const response = await fetch('/api/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(orderData),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('Order creation failed:', data);
      throw new Error(data.error || data.message || 'Failed to create order');
    }

    return { ...data, externalReference, orderId: data.id };
  };

  const clearCart = async () => {
    if (!session?.user?.id) return;

    try {
      const response = await fetch(`/api/cart?userId=${session.user.id}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Failed to clear cart');
      }
    } catch (error) {
      console.error('Error clearing cart:', error);
    }
  };

  const handleMpesaPayment = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!userData?.number || !cartData || !primaryAddress) {
      toast.error('Missing required information. Please ensure your profile has a phone number and address.');
      setPaymentStatus({
        status: 'error',
        message: 'Missing required information. Please ensure your profile has a phone number and address.'
      });
      return;
    }

    const subtotal = cartData.items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    const vatRate = 0.16;
    const vat = subtotal * vatRate;
    const totalAmount = subtotal + vat;

    try {
      setPaymentStatus({
        status: 'loading',
        message: 'Processing payment...'
      });
      toast.loading('Processing payment...');

      const orderResult = await createOrder();
      const externalReference = orderResult.externalReference;
      const orderId = orderResult.orderId; // Access the orderId here.

      const payheroClient = new PayheroClient();
      const phoneNumber = userData.number.toString();
      const formattedPhoneNumber = `0${phoneNumber.slice(-9)}`;

      const callbackUrl = `${window.location.origin}/api/payhero/callback`;

      const paymentRequest = await payheroClient.createPaymentRequest(
        Math.ceil(totalAmount),
        formattedPhoneNumber,
        callbackUrl,
        externalReference
      );

      if (!paymentRequest) {
        throw new Error('Failed to initiate payment request with Payhero.');
      }

      setPaymentStatus({
        status: 'success',
        message: 'Payment request initiated. Awaiting confirmation...',
        reference: paymentRequest.reference
      });

      toast.success('Payment request initiated. Awaiting confirmation...');

      await clearCart();
      startPaymentStatusCheck(paymentRequest.reference, orderId); // Pass orderId to the status check function.
    } catch (err) {
      console.error("Payment Error:", err);
      setPaymentStatus({
        status: 'error',
        message: err instanceof Error ? err.message : 'Payment processing failed'
      });
      toast.error(err instanceof Error ? err.message : 'Payment processing failed');
    }
  };

  const startPaymentStatusCheck = async (reference: string, orderId: string) => {
    let attempts = 0;
    const maxAttempts = 20;
    const payheroClient = new PayheroClient();

    const interval = setInterval(async () => {
      try {
        const paymentStatusResponse = await payheroClient.getPaymentRequestStatus(reference);

        if (paymentStatusResponse && paymentStatusResponse.status === "SUCCESS") {
          clearInterval(interval);

          setPaymentStatus({
            status: 'success',
            message: 'Payment completed and order created successfully!',
            reference: reference
          });
          toast.success('Payment completed and order created successfully!');
          window.location.href = `/order/success?orderId=${orderId}`; // Use the orderId here.
        } else if (paymentStatusResponse && paymentStatusResponse.status === "FAILED") {
          clearInterval(interval);
          setPaymentStatus({
            status: 'error',
            message: 'Payment Failed. Please try again.',
            reference: reference
          });
          toast.error('Payment Failed. Please try again.');
          return;
        }

        attempts++;
        if (attempts >= maxAttempts) {
          clearInterval(interval);
          setPaymentStatus({
            status: 'error',
            message: 'Payment verification timed out. Please check your order status.',
            reference: reference
          });
          toast.error('Payment verification timed out. Please check your order status.');
        }
      } catch (error) {
        clearInterval(interval);
        setPaymentStatus({
          status: 'error',
          message: 'Failed to verify payment status',
          reference: reference
        });
        toast.error('Failed to verify payment status');
      }
    }, 7000);
  };

  if (loading || status === 'loading') {
    return <CheckoutPageSkeleton />;
  }

  if (error) {
    return <div>Error loading data: {error}</div>;
  }

  if (!cartData || !cartData.items || cartData.items.length === 0) {
    router.push('/');
    return null;
  }

  const subtotal = cartData.items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const vatRate = 0.16;
  const vat = subtotal * vatRate;
  const total = subtotal + vat;

  const formattedSubtotal = subtotal.toLocaleString('en-KE', { style: 'currency', currency: 'KES' });
  const formattedVAT = vat.toLocaleString('en-KE', { style: 'currency', currency: 'KES' });
  const formattedTotal = total.toLocaleString('en-KE', { style: 'currency', currency: 'KES' });

    return (
        <section className="bg-white py-8 antialiased dark:bg-gray-900 md:py-16">
            <form onSubmit={handleMpesaPayment} className="mx-auto max-w-screen-xl px-4 2xl:px-0">

                <div className="mt-6 sm:mt-8 lg:flex lg:items-start lg:gap-12 xl:gap-16">
                    <div className="min-w-0 flex-1 space-y-8">
                        <div className="space-y-4">
                            <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex justify-between items-center">Delivery Details
                                <button
                                    type="button"
                                    onClick={() => router.push('/account')}
                                    className="text-sm font-medium text-primary-600 hover:text-primary-700 dark:text-primary-500"
                                >
                                    Edit
                                </button>
                            </h2>

                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                <div>
                                    <label htmlFor="your_name" className="mb-2 block text-sm font-medium text-gray-900 dark:text-white"> Name </label>
                                    <input disabled value={userData?.name} type="text" id="your_name" className="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder:text-gray-400 dark:focus:border-primary-500 dark:focus:ring-primary-500" placeholder={userData?.name} required />
                                </div>

                                <div>
                                    <label htmlFor="your_email" className="mb-2 block text-sm font-medium text-gray-900 dark:text-white"> Email </label>
                                    <input disabled value={userData?.email} type="email" id="your_email" className="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder:text-gray-400 dark:focus:border-primary-500 dark:focus:ring-primary-500" placeholder={userData?.email} required />
                                </div>


                                <div>
                                    <label htmlFor="street" className="mb-2 block text-sm font-medium text-gray-900 dark:text-white"> Street Name </label>
                                    <input disabled value={primaryAddress?.street || ''} type="text" id="street" className="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder:text-gray-400 dark:focus:border-primary-500 dark:focus:ring-primary-500" placeholder={primaryAddress?.street || ''} required />
                                </div>

                                <div>
                                    <label htmlFor="country" className="mb-2 block text-sm font-medium text-gray-900 dark:text-white"> Country </label>
                                    <input disabled value={countryName || ''} type="text" id="country" className="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder:text-gray-400 dark:focus:border-primary-500 dark:focus:ring-primary-500" placeholder={countryName || ''} required />
                                </div>

                                <div>
                                    <label htmlFor="county" className="mb-2 block text-sm font-medium text-gray-900 dark:text-white"> County </label>
                                    <input disabled value={countyName || ''} type="text" id="county" className="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder:text-gray-400 dark:focus:border-primary-500 dark:focus:ring-primary-500" placeholder={countyName || ''} required />
                                </div>

                                <div>
                                    <label htmlFor="city" className="mb-2 block text-sm font-medium text-gray-900 dark:text-white"> City </label>
                                    <input disabled value={cityName || ''} type="text" id="city" className="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder:text-gray-400 dark:focus:border-primary-500 dark:focus:ring-primary-500" placeholder={cityName || ''} required />
                                </div>


                                <div>
                                    <label htmlFor="phone-input-3" className="mb-2 block text-sm font-medium text-gray-900 dark:text-white"> Phone Number </label>
                                    <div className="flex items-center">
                                        <div className="relative w-full">
                                            <input disabled value={userData?.number} type="number" id="phone-input" className="z-20 block w-full rounded-e-lg border border-s-0 border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:border-s-gray-700  dark:bg-gray-700 dark:text-white dark:placeholder:text-gray-400 dark:focus:border-primary-500" placeholder={`+254${userData?.number?.slice(-9)}`} required />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Payment</h3>

                            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                                <div className="rounded-lg border border-gray-200 bg-gray-50 p-4 ps-4 dark:border-gray-700 dark:bg-gray-800">
                                    <div className="flex items-start">
                                        <div className="flex h-5 items-center">
                                            <input disabled id="credit-card" aria-describedby="credit-card-text" type="radio" name="payment-method" className="h-4 w-4 border-gray-300 bg-white text-primary-600 focus:ring-2 focus:ring-primary-600 dark:border-gray-600 dark:bg-gray-700 dark:ring-offset-gray-800 dark:focus:ring-primary-600" checked />
                                        </div>

                                        <div className="ms-4 text-sm">
                                            <label htmlFor="credit-card" className="font-medium leading-none text-gray-900 dark:text-white"> M-Pesa </label>
                                            <p id="credit-card-text" className="mt-1 text-xs font-normal text-gray-500 dark:text-gray-400">Pay with mpesa</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div className="mt-6 w-full space-y-6 sm:mt-8 lg:mt-0 lg:max-w-xs xl:max-w-md">
                        <div className="flow-root">
                            <div className="-my-3 divide-y divide-gray-200 dark:divide-gray-800">
                                <dl className="flex items-center justify-between gap-4 py-3">
                                    <dt className="text-base font-normal text-gray-500 dark:text-gray-400">Subtotal</dt>
                                    <dd className="text-base font-medium text-gray-900 dark:text-white">{formattedSubtotal}</dd>
                                </dl>

                                <dl className="flex items-center justify-between gap-4 py-3">
                                    <dt className="text-base font-normal text-gray-500 dark:text-gray-400">VAT (16%)</dt>
                                    <dd className="text-base font-medium text-gray-900 dark:text-white">{formattedVAT}</dd>
                                </dl>

                                <dl className="flex items-center justify-between gap-4 py-3">
                                    <dt className="text-base font-bold text-gray-900 dark:text-white">Total (VAT incl.)</dt>
                                    <dd className="text-base font-bold text-gray-900 dark:text-white">{formattedTotal}</dd>
                                </dl>
                            </div>
                        </div>

                        {paymentStatus.message && (
                            <div className={`p-4 rounded-lg ${paymentStatus.status === 'error'
                                ? 'bg-red-100 text-red-700'
                                : paymentStatus.status === 'success'
                                    ? 'bg-green-100 text-green-700'
                                    : 'bg-blue-100 text-blue-700'
                                }`}>
                                {paymentStatus.message}
                            </div>
                        )}

                        <div className="space-y-3">
                            <button
                                type="submit"
                                disabled={paymentStatus.status === 'loading'}
                                className="flex w-full items-center justify-center rounded-lg bg-primary-700 px-5 py-2.5 text-sm font-medium text-white hover:bg-primary-800 focus:outline-none focus:ring-4 focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                {paymentStatus.status === 'loading' ? 'Processing...' : 'Pay with M-Pesa'}
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </section>
    );
};

export default CheckoutPage;