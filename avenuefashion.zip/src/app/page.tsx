import { cache } from 'react';
import Navbar from '@/components/customer/Navbar';
import Footer from '@/components/customer/Footer';
import Hero from '@/components/customer/Hero';
import { CategoryList } from '@/components/customer/CategoryList';
import { ProductList } from '@/components/customer/ProductList';
import { Filters } from '@/components/customer/Filters';
import { UserDetailsDialog } from '@/components/customer/UserDetailsDialog';

interface Category {
    id: string;
    name: string;
    image: string;
    slug: string;
}

type Product = {
    id: string;
    slug: string;
    name: string;
    description: string;
    price: number;
    categoryId: string;
    images: string[];
    stock: number;
    category: {
        id: string;
        name: string;
    };
};

interface HeroProps {
    id: string;
    title: string;
    subtitle: string;
    image: string;
    link: string;
    isActive: boolean;
}

const PRODUCTS_PER_PAGE = 20;

// Function to shuffle an array in place (Fisher-Yates shuffle)
function shuffleArray<T>(array: T[]): T[] {
    const newArray = [...array]
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
}

// Data fetching functions (using `cache` to memoize)
const getCategories = cache(async (): Promise<Category[]> => {
    const res = await fetch(`${process.env.NEXT_PUBLIC_WEBSITE_URL}/api/categories`, {
        cache: 'force-cache',
    });
    return shuffleArray(await res.json());
});

const getHeros = cache(async (): Promise<HeroProps[]> => {
    const res = await fetch(`${process.env.NEXT_PUBLIC_WEBSITE_URL}/api/heros`, {
        cache: 'force-cache', 
    });
    return await res.json();
});

const getProducts = cache(
    async (
        categoryId: string | null,
        minPrice: number | undefined,
        maxPrice: number | undefined,
        sortBy: 'price' | 'createdAt' | 'name',
        order: 'asc' | 'desc',
        page: number,
        limit: number,
    ): Promise<{ products: Product[]; totalCount: number }> => {
        const params = new URLSearchParams();
        if (categoryId) params.append('categoryId', categoryId);
        if (minPrice !== undefined) params.append('minPrice', minPrice.toString());
        if (maxPrice !== undefined) params.append('maxPrice', maxPrice.toString());
        params.append('sortBy', sortBy);
        params.append('order', order);
        params.append('page', page.toString());
        params.append('limit', limit.toString());

        const response = await fetch(`${process.env.NEXT_PUBLIC_WEBSITE_URL}/api/products?${params.toString()}`, {
            cache: 'no-store'
        });
        return await response.json();
    },
);

export default async function Home() {
    const categories = await getCategories();
    const heros = await getHeros();

    // Fetch products without any filters or pagination
    const { products, totalCount } = await getProducts(
        null, // No category filter
        undefined, // No minPrice filter
        undefined, // No maxPrice filter
        'createdAt', // Default sort by createdAt
        'desc', // Default order
        1, // Default page
        PRODUCTS_PER_PAGE, // Default limit
    );

    // Shuffle products on the server
    const shuffledProducts = shuffleArray(products);

    return (
        <>
            <Navbar />
            <Hero />
            <main className="bg-gray-50 py-8 antialiased dark:bg-gray-900 md:py-12">
                <div className="mx-auto max-w-screen-xl px-4 2xl:px-0">
                    <CategoryList categories={categories} />
                    <section>
                        <h2 className="text-xl font-semibold text-gray-900 dark:text-white sm:text-2xl mb-4">Products</h2>
                        <Filters
                            categories={categories}
                            initialCategory={''} // No initial category
                            initialSortBy={'createdAt'} // Default sort by createdAt
                            initialOrder={'desc'} // Default order
                            initialMinPrice={undefined} // No initial minPrice
                            initialMaxPrice={undefined} // No initial maxPrice
                        />
                        <ProductList products={shuffledProducts} totalCount={totalCount} initialPage={1} productsPerPage={PRODUCTS_PER_PAGE} />
                    </section>
                </div>
            </main>
            <Footer />
            <UserDetailsDialog />
        </>
    );
}