import { NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { isAuthenticated } from '@/lib/auth-utils';
import { auth } from '@/auth';

/**
 * @swagger
 * /api/cart:
 *   get:
 *     summary: Retrieve the user's cart items.
 *     description: Retrieves the items in the user's cart.  Requires authentication.
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: query
 *         name: userId
 *         schema:
 *           type: string
 *         required: true
 *         description: The ID of the user whose cart is being retrieved.  Must match the ID of the authenticated user.
 *     responses:
 *       200:
 *         description: Successful retrieval of cart items. Returns an array of cart items.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 items:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: string
 *                         description: The unique identifier for the item.
 *                       cartId:
 *                         type: string
 *                         description: The ID of the cart the item belongs to.
 *                       productId:
 *                         type: string
 *                         description: The ID of the product in the item.
 *                       quantity:
 *                         type: integer
 *                         description: The quantity of the product in the item.
 *                       variation:
 *                         type: string
 *                         nullable: true
 *                         description: The variation of the product in the item (e.g., color, size).  Can be null.
 *                       createdAt:
 *                         type: string
 *                         format: date-time
 *                         description: The date and time the item was created.
 *                       updatedAt:
 *                         type: string
 *                         format: date-time
 *                         description: The date and time the item was last updated.
 *                       product:
 *                         type: object
 *                         description: The product details associated with the item.
 *                         properties:
 *                           id:
 *                             type: string
 *                             description: The unique identifier for the product.
 *                           name:
 *                             type: string
 *                             description: The name of the product.
 *                           description:
 *                             type: string
 *                             description: A description of the product.
 *                           price:
 *                             type: number
 *                             format: float
 *                             description: The price of the product.
 *                           imageUrl:
 *                             type: string
 *                             description: URL of an image of the product.
 *                           categoryId:
 *                             type: string
 *                             description: The ID of the category the product belongs to.
 *                           createdAt:
 *                             type: string
 *                             format: date-time
 *                             description: The date and time the product was created.
 *                           updatedAt:
 *                             type: string
 *                             format: date-time
 *                             description: The date and time the product was last updated.
 *       400:
 *         description: User ID is required.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that the user ID is missing.
 *       401:
 *         description: Unauthorized. User is not authenticated.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that the user is not authenticated.
 *       403:
 *         description: Unauthorized to access this cart. User ID in the request does not match the authenticated user.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that the user is not authorized to access this cart.
 *       500:
 *         description: Failed to fetch cart.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that fetching the cart failed.
 */
export async function GET(request: Request) {
    const session = await auth();
    const user = session?.user;

    if (!user) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    try {
        const { searchParams } = new URL(request.url);
        const userId = searchParams.get('userId');

        if (!userId) {
            return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
        }

        if (userId !== user.id) {
            return NextResponse.json({ error: 'Unauthorized to access this cart' }, { status: 403 });
        }

        // Fetch the cart from the database
        const cart = await prisma.cart.findUnique({
            where: {
                userId: userId,
            },
            include: {
                items: {
                    include: {
                        product: true
                    }
                }
            }
        });

        if (!cart) {
            return NextResponse.json({ items: [] }); // Return an empty cart if not found
        }

        return NextResponse.json({ items: cart.items });

    } catch (error) {
        console.error('Error fetching cart:', error);
        return NextResponse.json({ error: 'Failed to fetch cart' }, { status: 500 });
    }
}

/**
 * @swagger
 * /api/cart:
 *   post:
 *     summary: Add or update an item in the user's cart.
 *     description: Adds a new item to the user's cart or updates the quantity of an existing item. Requires authentication.
 *     security:
 *       - BearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               userId:
 *                 type: string
 *                 description: The ID of the user. Must match the ID of the authenticated user.
 *               productId:
 *                 type: string
 *                 description: The ID of the product to add or update.
 *               quantity:
 *                 type: integer
 *                 description: The quantity of the product to add or update.
 *               variation:
 *                 type: string
 *                 nullable: true
 *                 description: The variation of the product (e.g., color, size). Can be null.
 *             required:
 *               - userId
 *               - productId
 *               - quantity
 *     responses:
 *       200:
 *         description: Successful addition or update of the cart item. Returns the updated list of cart items.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 items:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: string
 *                         description: The unique identifier for the item.
 *                       cartId:
 *                         type: string
 *                         description: The ID of the cart the item belongs to.
 *                       productId:
 *                         type: string
 *                         description: The ID of the product in the item.
 *                       quantity:
 *                         type: integer
 *                         description: The quantity of the product in the item.
 *                       variation:
 *                         type: string
 *                         nullable: true
 *                         description: The variation of the product in the item (e.g., color, size).  Can be null.
 *                       createdAt:
 *                         type: string
 *                         format: date-time
 *                         description: The date and time the item was created.
 *                       updatedAt:
 *                         type: string
 *                         format: date-time
 *                         description: The date and time the item was last updated.
 *                       product:
 *                         type: object
 *                         description: The product details associated with the item.
 *                         properties:
 *                           id:
 *                             type: string
 *                             description: The unique identifier for the product.
 *                           name:
 *                             type: string
 *                             description: The name of the product.
 *                           description:
 *                             type: string
 *                             description: A description of the product.
 *                           price:
 *                             type: number
 *                             format: float
 *                             description: The price of the product.
 *                           imageUrl:
 *                             type: string
 *                             description: URL of an image of the product.
 *                           categoryId:
 *                             type: string
 *                             description: The ID of the category the product belongs to.
 *                           createdAt:
 *                             type: string
 *                             format: date-time
 *                             description: The date and time the product was created.
 *                           updatedAt:
 *                             type: string
 *                             format: date-time
 *                             description: The date and time the product was last updated.
 *       400:
 *         description: User ID, Product ID, and Quantity are required.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that one or more required parameters are missing.
 *       401:
 *         description: Unauthorized. User is not authenticated.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that the user is not authenticated.
 *       403:
 *         description: Unauthorized to modify this cart. User ID in the request does not match the authenticated user.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that the user is not authorized to modify this cart.
 *       500:
 *         description: Failed to add to cart.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that adding to the cart failed.
 */
export async function POST(request: Request) {
    const session = await auth();
    const user = session?.user;

    if (!user) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    try {
        const { userId, productId, quantity, variation } = await request.json();

        if (!userId || !productId || !quantity) {
            return NextResponse.json({ error: 'User ID, Product ID, and Quantity are required' }, { status: 400 });
        }

        if (userId !== user.id) {
            return NextResponse.json({ error: 'Unauthorized to modify this cart' }, { status: 403 });
        }

        // Fetch the cart from the database
        let cart = await prisma.cart.findUnique({
            where: {
                userId: userId,
            },
            include: {
                items: true
            }
        });

        if (!cart) {
            // Create a new cart if it doesn't exist
            cart = await prisma.cart.create({
                data: {
                    userId: userId,
                },
                include: {
                    items: true
                }
            });
        }

        // Check if the item already exists in the cart
        const existingItem = cart.items.find(item => item.productId === productId && item.variation === variation);

        if (existingItem) {
            // Update the quantity of the existing item
            await prisma.item.update({
                where: {
                    id: existingItem.id,
                },
                data: {
                    quantity: quantity,
                },
            });
        } else {
            // Add a new item to the cart
            await prisma.item.create({
                data: {
                    cartId: cart.id,
                    productId: productId,
                    quantity: quantity,
                    variation: variation,
                },
            });
        }

        // Re-fetch the cart with updated items
        const updatedCart = await prisma.cart.findUnique({
            where: {
                userId: userId,
            },
            include: {
                items: {
                    include: {
                        product: true
                    }
                }
            }
        });

        return NextResponse.json({ items: updatedCart!.items }, { status: 200 });

    } catch (error) {
        console.error('Error adding to cart:', error);
        return NextResponse.json({ error: 'Failed to add to cart' }, { status: 500 });
    }
}

/**
 * @swagger
 * /api/cart:
 *   delete:
 *     summary: Remove an item from the user's cart.
 *     description: Removes a specific item from the user's cart based on the product ID and variation (if provided). Requires authentication. If only userId is provided, the entire cart is cleared.
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: query
 *         name: userId
 *         schema:
 *           type: string
 *         required: true
 *         description: The ID of the user whose cart is being modified. Must match the ID of the authenticated user.
 *       - in: query
 *         name: productId
 *         schema:
 *           type: string
 *         required: false
 *         description: The ID of the product to remove from the cart. If not provided, the entire cart will be cleared.
 *       - in: query
 *         name: variation
 *         schema:
 *           type: string
 *           nullable: true
 *         required: false
 *         description: The variation of the product to remove. If not provided, the first item matching the productId will be removed.
 *     responses:
 *       200:
 *         description: Successful removal of the cart item or clearing of the cart. Returns the updated list of cart items.  If cart is cleared, returns empty list of items.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 items:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: string
 *                         description: The unique identifier for the item.
 *                       cartId:
 *                         type: string
 *                         description: The ID of the cart the item belongs to.
 *                       productId:
 *                         type: string
 *                         description: The ID of the product in the item.
 *                       quantity:
 *                         type: integer
 *                         description: The quantity of the product in the item.
 *                       variation:
 *                         type: string
 *                         nullable: true
 *                         description: The variation of the product in the item (e.g., color, size).  Can be null.
 *                       createdAt:
 *                         type: string
 *                         format: date-time
 *                         description: The date and time the item was created.
 *                       updatedAt:
 *                         type: string
 *                         format: date-time
 *                         description: The date and time the item was last updated.
 *                       product:
 *                         type: object
 *                         description: The product details associated with the item.
 *                         properties:
 *                           id:
 *                             type: string
 *                             description: The unique identifier for the product.
 *                           name:
 *                             type: string
 *                             description: The name of the product.
 *                           description:
 *                             type: string
 *                             description: A description of the product.
 *                           price:
 *                             type: number
 *                             format: float
 *                             description: The price of the product.
 *                           imageUrl:
 *                             type: string
 *                             description: URL of an image of the product.
 *                           categoryId:
 *                             type: string
 *                             description: The ID of the category the product belongs to.
 *                           createdAt:
 *                             type: string
 *                             format: date-time
 *                             description: The date and time the product was created.
 *                           updatedAt:
 *                             type: string
 *                             format: date-time
 *                             description: The date and time the product was last updated.
 *       400:
 *         description: User ID is required.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that the user ID is missing.
 *       401:
 *         description: Unauthorized. User is not authenticated.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that the user is not authenticated.
 *       403:
 *         description: Unauthorized to modify this cart. User ID in the request does not match the authenticated user.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that the user is not authorized to modify this cart.
 *       404:
 *         description: Cart not found or Item not found in cart.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that the cart or the item to delete was not found.
 *       500:
 *         description: Failed to remove from cart.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that removing from the cart failed.
 */
export async function DELETE(request: Request) {
    const session = await auth();
    const user = session?.user;

    if (!user) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    try {
        const { searchParams } = new URL(request.url);
        const userId = searchParams.get('userId');
        const productId = searchParams.get('productId');

        if (!userId) {
            return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
        }

        if (userId !== user.id) {
            return NextResponse.json({ error: 'Unauthorized to modify this cart' }, { status: 403 });
        }

        // Find the cart
        const cart = await prisma.cart.findUnique({
            where: {
                userId: userId,
            },
            include: {
                items: true
            }
        });

        if (!cart) {
            return NextResponse.json({ error: 'Cart not found' }, { status: 404 });
        }

        // If productId is NOT provided, clear the entire cart.
        if (!productId) {
            await prisma.item.deleteMany({
                where: {
                    cartId: cart.id,
                },
            });

            return NextResponse.json({items: []});
        }
        // Find the item in the cart
        const itemToDelete = cart.items.find(item => item.productId === productId);

        if (!itemToDelete) {
            return NextResponse.json({ error: 'Item not found in cart' }, { status: 404 });
        }

        // Delete the item
        await prisma.item.delete({
            where: {
                id: itemToDelete.id,
            },
        });

        // Refetch the cart
         const updatedCart = await prisma.cart.findUnique({
            where: {
                userId: userId,
            },
            include: {
                items: {
                    include: {
                        product: true
                    }
                }
            }
        });

        return NextResponse.json({ items: updatedCart!.items });

    } catch (error) {
        console.error('Error deleting from cart:', error);
        return NextResponse.json({ error: 'Failed to remove from cart' }, { status: 500 });
    }
}

/**
 * @swagger
 * /api/cart:
 *   put:
 *     summary: Clear the user's cart.
 *     description: Removes all items from the user's cart. Requires authentication.
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: query
 *         name: userId
 *         schema:
 *           type: string
 *         required: true
 *         description: The ID of the user whose cart is being cleared. Must match the ID of the authenticated user.
 *     responses:
 *       200:
 *         description: Successful clearing of the cart.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: Success message indicating that the cart was cleared.
 *       400:
 *         description: User ID is required.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that the user ID is missing.
 *       401:
 *         description: Unauthorized. User is not authenticated.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that the user is not authenticated.
 *       403:
 *         description: Unauthorized to clear this cart. User ID in the request does not match the authenticated user.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that the user is not authorized to clear this cart.
 *       500:
 *         description: Failed to clear cart.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   description: Error message indicating that clearing the cart failed.
 */
export async function PUT(request: Request) {
    const session = await auth();
    const user = session?.user;

    if (!user) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    try {
        const { searchParams } = new URL(request.url);
        const userId = searchParams.get('userId');

        if (!userId) {
            return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
        }

        if (userId !== user.id) {
            return NextResponse.json({ error: 'Unauthorized to clear this cart' }, { status: 403 });
        }

        const cart = await prisma.cart.findUnique({
            where: {
                userId: userId,
            },
            include: {
                items: true,
            },
        });

        if (!cart) {
            return NextResponse.json({ message: 'Cart is already empty' });
        }

        // Delete all items in the cart
        await prisma.item.deleteMany({
            where: {
                cartId: cart.id,
            },
        });

        return NextResponse.json({ message: 'Cart cleared successfully' });

    } catch (error) {
        console.error('Error clearing cart:', error);
        return NextResponse.json({ error: 'Failed to clear cart' }, { status: 500 });
    }
}