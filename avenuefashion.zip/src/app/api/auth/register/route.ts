import { NextResponse } from 'next/server';
import { PrismaClient, UserRole } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

export async function POST(request: Request) {
  try {
    const { name, email, password, phoneNumber, countryId, countyId, cityId, street } = await request.json();

    // Validation
    if (!name || !email || !password || !phoneNumber || !countryId || !countyId || !cityId || !street) {
      return NextResponse.json(
        { error: 'Name, email, password, phoneNumber, countryId, countyId, cityId, and street are required.' },
        { status: 400 }
      );
    }

    // Convert email to lowercase
    const normalizedEmail = email.toLowerCase();

    // Check if the user already exists by email
    const existingUserByEmail = await prisma.user.findUnique({
      where: {
        email: normalizedEmail,
      },
    });

    if (existingUserByEmail) {
      return NextResponse.json({ error: 'User with this email already exists.' }, { status: 400 });
    }

    // Transform phone number: remove leading 0 and prefix with 254
    let formattedPhoneNumber = phoneNumber.replace(/^0/, ''); // Remove leading 0
    formattedPhoneNumber = `254${formattedPhoneNumber}`; // Prefix with 254

    // Validate phone number length (should be 12 digits after transformation)
    if (formattedPhoneNumber.length !== 12 || !/^\d+$/.test(formattedPhoneNumber)) {
      return NextResponse.json(
        { error: 'Invalid phone number. It should be 9 digits long (excluding the leading 0).' },
        { status: 400 }
      );
    }

      // Check if the user already exists by phone number
      const existingUserByNumber = await prisma.user.findUnique({
        where: {
          number: parseInt(formattedPhoneNumber, 10).toString(),
        },
      });

      if (existingUserByNumber) {
        return NextResponse.json({ error: 'User with this phone number already exists.' }, { status: 400 });
      }


    // Validate location IDs
    const [country, county, city] = await Promise.all([
      prisma.location.findUnique({
        where: { id: countryId, type: 'country' },
      }),
      prisma.location.findUnique({
        where: { id: countyId, type: 'county' },
      }),
      prisma.location.findUnique({
        where: { id: cityId, type: 'city' },
      }),
    ]);

    if (!country || !county || !city) {
      return NextResponse.json({ error: 'Invalid location details provided.' }, { status: 400 });
    }

    // Validate location hierarchy
    if (county.countryId !== country.id || city.countyId !== county.id) {
      return NextResponse.json({ error: 'Invalid location hierarchy.' }, { status: 400 });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user
    const newUser = await prisma.user.create({
      data: {
        name,
        email: normalizedEmail,
        password: hashedPassword,
        number: parseInt(formattedPhoneNumber, 10).toString(),
        role: UserRole.customer,
        countryId,
        countyId,
        cityId,
        street,
      },
    });

    // Respond with success message
    return NextResponse.json({ message: 'User registered successfully!' }, { status: 201 });
  } catch (error) {
    console.error('Registration error:', error);
    if (error instanceof Error && error.message.includes('Unique constraint failed')) {
      return NextResponse.json({ error: 'User with this email or phone number already exists.' }, { status: 409 });
    }
    return NextResponse.json({ error: 'Something went wrong. Please try again later.' }, { status: 500 });
  }
}