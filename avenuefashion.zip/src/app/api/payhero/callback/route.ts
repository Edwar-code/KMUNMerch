import { NextResponse } from 'next/server';
import { PayheroClient } from '@/lib/PayheroClient';
import prisma from '@/lib/db';
import { PaymentStatus, OrderStatus } from '@prisma/client';

export async function POST(req: Request) {
    try {
        const body = await req.json();
        const payhero = new PayheroClient();
        const result = payhero.processCallback(body);

        if (result.success) {
            // Extract relevant data from the PayHero callback
            const transactionId = result.data?.transactionId;
            const amount = result.data?.amount;
            const paymentRequestId = result.data?.paymentRequestId;
            const phoneNumber = result.data?.phoneNumber;

            const payheroReference = body?.external_reference;

            if (!transactionId || !amount || !paymentRequestId || !phoneNumber || !payheroReference) {
                console.error('Missing data in PayHero callback.');
                return NextResponse.json(
                    { message: 'Missing data in PayHero callback', error: 'Missing data' },
                    { status: 400 }
                );
            }

            // 1. Find the Order record using the payheroReference.
            const order = await prisma.order.findFirst({
    where: {
        payheroReference: payheroReference,
    },
});

            if (!order) {
                console.error(`Order record not found for payheroReference: ${payheroReference}`);
                return NextResponse.json(
                    { message: 'Order record not found' },
                    { status: 404 }
                );
            }

            // 2. Update the Order record with transaction details and status
            try {
                await prisma.order.update({
                    where: {
                        id: order.id, 
                    },
                    data: {
                        transactionId: transactionId,
                        paymentStatus: PaymentStatus.completed,
                        status: OrderStatus.processing 
                    },
                });

            } catch (dbUpdateError) {
                console.error('Error updating database:', dbUpdateError);
                return NextResponse.json(
                    { message: 'Error updating database', error: dbUpdateError },
                    { status: 500 }
                );
            }

            return NextResponse.json({ message: 'Payment processed successfully' });
        } else {
            return NextResponse.json(
                { message: 'Payment failed', error: result.error },
                { status: 400 }
            );
        }

    } catch (error) {
        console.error('Callback error:', error);
        return NextResponse.json(
            { message: 'Error processing callback' },
            { status: 500 }
        );
    }
}