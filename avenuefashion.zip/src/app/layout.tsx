import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { SpeedInsights } from "@vercel/speed-insights/next";
import { Analytics } from "@vercel/analytics/next";
import { Providers } from "@/components/providers";
import Script from "next/script";
import PushNotificationManager from "@/components/PushNotification";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});
const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Avenue Fashion | Kenya's Premier Online Fashion Store",
  description: "Discover the latest trends in fashion at Avenue Fashion. Shop quality clothes, shoes, jewelry, and accessories for men, women, and kids. Enjoy seamless shopping, secure M-Pesa payments, and fast delivery across Kenya.",
  keywords: "Avenue Fashion, Kenya, online fashion, clothes, shoes, jewelry, accessories, M-Pesa payments, fashion store, men's fashion, women's fashion, kid's fashion, shop online Kenya",
  openGraph: {
    title: "Avenue Fashion | Kenya's Premier Online Fashion Store",
    description: "Shop the latest styles in clothing, shoes, jewelry, and more at Avenue Fashion. Offering secure M-Pesa payments and fast delivery in Kenya.",
    url: "https://avenuefashion.co.ke",
    type: "website",
  },
  icons: {
    icon: '/favicon.ico',
  },
  other: {
    "google-adsense-account": "ca-pub-2093346140167197",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
      <meta name="google-adsense-account" content="ca-pub-2093346140167197" />
      <Script
        id="Cookiebot"
        src="https://consent.cookiebot.com/uc.js"
        data-cbid="16457812-0bf1-4899-8632-825b19dc9492"
        strategy="beforeInteractive"
      />
      <Script
        async
        src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2093346140167197"
        crossOrigin="anonymous"
        strategy="afterInteractive"
      />
      </head>
      <body
      className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
      <Providers>
        {children}
      </Providers>
      <SpeedInsights />
      <Analytics />
      
      <Script 
        src="https://www.googletagmanager.com/gtag/js?id=G-DJBST93BTQ" 
        strategy="afterInteractive"
      />
      <Script id="google-analytics" strategy="afterInteractive">
        {`
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-DJBST93BTQ');
        `}
      </Script>
      
      <Script 
        src="https://accounts.google.com/gsi/client" 
        strategy="afterInteractive"
      />
      </body>
    </html>
  );
}