'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';

type Product = {
    id: string;
    slug: string;
    name: string;
    description: string;
    price: number;
    categoryId: string;
    images: string[];
    stock: number;
    category: {
        id: string;
        name: string;
    };
};

interface ProductListProps {
    products: Product[];
    totalCount: number;
    initialPage: number;
    productsPerPage: number;
}

export const ProductList: React.FC<ProductListProps> = ({ products, totalCount, initialPage, productsPerPage }) => {
    const { data: session } = useSession();
    const userID = session?.user?.id;
    const router = useRouter();

    const [displayedProducts, setDisplayedProducts] = useState<Product[]>(products);
    const [wishlist, setWishlist] = useState<{ [key: string]: boolean }>({});
    const [loadingWishlist, setLoadingWishlist] = useState<{
        [key: string]: boolean;
    }>({});
    const [randomImages, setRandomImages] = useState<{ [productId: string]: string }>({});
    const [currentPage, setCurrentPage] = useState(initialPage);
    const [loading, setLoading] = useState(false)


    // Update displayed products when the products prop changes
    useEffect(() => {
        setDisplayedProducts(products);
    }, [products]);

    useEffect(() => {
        const initialRandomImages: { [productId: string]: string } = {};
        products.forEach((product: Product) => {
            initialRandomImages[product.id] = product.images[Math.floor(Math.random() * product.images.length)];
        });
        setRandomImages(initialRandomImages);
    }, [products])

    useEffect(() => {
        const fetchWishlist = async () => {
            if (userID) {
                try {
                    const response = await fetch(`/api/wishlist?userId=${userID}`);
                    const data = await response.json();
                    const wishlistState = data.reduce((acc: any, item: any) => {
                        acc[item.productId] = true;
                        return acc;
                    }, {});
                    setWishlist(wishlistState);
                } catch (error) {
                    console.error('Error fetching wishlist:', error);
                }
            }
        };

        fetchWishlist();

    }, [userID]);

    const handleWishlistToggle = async (productId: string) => {
        if (!session?.user?.id) {
            toast.error('Please log in to add items to wishlist');
            router.push('/login');
            return;
        }

        setLoadingWishlist((prev) => ({ ...prev, [productId]: true }));
        try {
            const response = await fetch(
                `/api/wishlist?userId=${userID}&productId=${productId}`,
                {
                    method: wishlist[productId] ? 'DELETE' : 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        userId: userID,
                        productId: productId,
                    }),
                }
            );

            const data: { message?: string } = await response.json();

            if (response.ok) {
                setWishlist((prev) => ({ ...prev, [productId]: !prev[productId] }));

                // Success toasts based on method
                if (wishlist[productId]) {
                    toast.success('Removed from wishlist');
                } else {
                    toast.success(data.message || 'Added to wishlist');
                }
            } else {
                toast.error(data.message || 'Failed to update wishlist');
            }
        } catch (error) {
            console.error('Error:', error);
            toast.error('Failed to update wishlist');
        } finally {
            setLoadingWishlist((prev) => ({ ...prev, [productId]: false }));
        }

    };

    const handleLoadMore = () => {
        setCurrentPage((prev) => prev + 1);
        const queryParams = new URLSearchParams(window.location.search);
        queryParams.set('page', (currentPage + 1).toString());
        router.push(`/?${queryParams.toString()}`)
    };

    // Skeleton Component
    const SkeletonItem = () => (
        <div className="group relative block overflow-hidden rounded-lg border border-gray-100 bg-white p-4 dark:border-gray-700 dark:bg-gray-900 animate-pulse">
            <div className="relative aspect-square overflow-hidden rounded-lg bg-gray-300 dark:bg-gray-700"></div>

            <div className="mt-4 space-y-2">
                <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-3/4"></div>
                <div className="h-3 bg-gray-300 dark:bg-gray-700 rounded w-1/2"></div>
                <div className="mt-2 flex items-center justify-between">
                    <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-1/3"></div>
                    <div className="h-3 bg-gray-300 dark:bg-gray-700 rounded w-1/4"></div>
                </div>
            </div>
        </div>
    );

    return (
        <>
            <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                {loading ? (
                    [...Array(productsPerPage)].map((_, index) => (
                        <SkeletonItem key={index} />
                    ))
                ) : (
                    displayedProducts.map((product) => {
                        const imageToShow = randomImages[product.id] || product.images[0];
                        return (
                            <div
                                key={product.slug}
                                className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-700 dark:bg-gray-800"
                            >
                                <div className="h-48 w-full overflow-hidden group relative">
                                    <Link href={`/${product.slug}`}>
                                        <Image
                                            width={430}
                                            height={224}
                                            className="mx-auto h-full w-full object-cover object-center rounded-lg transition-transform duration-300 group-hover:scale-110"
                                            src={imageToShow}
                                            alt={product.name}
                                            loader={() => imageToShow}
                                            unoptimized
                                        />
                                    </Link>
                                </div>

                                <div className="pt-4">
                                    <div className="mb-3 flex items-center justify-between gap-3">
                                        <span className="rounded bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                                            {product.category.name}
                                        </span>

                                        <div className="flex items-center justify-end gap-1">

                                            <button
                                                onClick={() => handleWishlistToggle(product.id)}
                                                type="button"
                                                className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-100 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                                            >
                                                <span className="sr-only">
                                                    {loadingWishlist[product.id]
                                                        ? 'Adding...'
                                                        : wishlist[product.id]
                                                            ? 'Remove from Wishlist'
                                                            : 'Add to Wishlist'}
                                                </span>
                                                <svg
                                                    className="h-4 w-4"
                                                    aria-hidden="true"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fill={wishlist[product.id] ? 'red' : 'none'}
                                                    viewBox="0 0 24 24"
                                                    stroke={wishlist[product.id] ? 'red' : 'currentColor'}
                                                >
                                                    <path
                                                        stroke="currentColor"
                                                        strokeLinecap="round"
                                                        strokeLinejoin="round"
                                                        strokeWidth="2"
                                                        d="M12 6C6.5 1 1 8 5.8 13l6.2 7 6.2-7C23 8 17.5 1 12 6Z"
                                                    />
                                                </svg>
                                            </button>
                                        </div>
                                    </div>

                                    <Link
                                        href={`/${product.slug}`}
                                        className="block text-base font-semibold leading-tight text-gray-900 hover:underline dark:text-white mb-2"
                                    >
                                        {product.name}
                                    </Link>

                                    <div className="mt-2 flex items-center justify-between gap-2">
                                        <p className="text-xl font-bold leading-tight text-gray-900 dark:text-primary-700">
                                            {`Ksh. ${product.price}`}
                                        </p>


                                    </div>
                                </div>
                            </div>
                        );
                    })
                )}
            </div>
            {totalCount > displayedProducts.length && (
                <div className="w-full text-center">
                    <button
                        onClick={handleLoadMore}
                        type="button"
                        className="rounded-lg border border-gray-200 bg-white px-5 py-2.5 text-sm font-medium text-gray-900 hover:bg-gray-100 hover:text-primary-700 focus:z-10 focus:outline-none focus:ring-4 focus:ring-gray-100 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white dark:focus:ring-gray-700"
                    >
                        Load More
                    </button>
                </div>
            )}
        </>
    );
};