'use client'

import Image from 'next/image';
import Link from 'next/link';
import React, { useEffect, useState } from 'react';

interface HeroProps {
    title: string;
    subtitle: string | null;
    image: string;
    link: string | null;
    isActive: boolean;
}

const Hero = () => {
    const [heroes, setHeroes] = useState<HeroProps[]>([]); // Array of all active heroes
    const [currentHeroIndex, setCurrentHeroIndex] = useState(0); // Index of the hero to display in the carousel
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [shouldShowHero, setShouldShowHero] = useState(false); // Decide to show hero or not

    const shuffleArray = (array: HeroProps[]) => {
        const newArray = [...array]; // Create a copy to avoid mutating the original
        for (let i = newArray.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
        }
        return newArray;
    };

    useEffect(() => {
        const fetchHeroData = async () => {
            setIsLoading(true);
            try {
                const response = await fetch('/api/heros?isActive=true'); 
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                const data = await response.json();

                if (Array.isArray(data) && data.length > 0) {
                    // Shuffle the heroes
                    const shuffledHeroes = shuffleArray(data);
                    setHeroes(shuffledHeroes);

                    // Decide whether to show the hero section at all
                    const showChance = Math.random(); // Number between 0 and 1
                    setShouldShowHero(showChance > 0.5); // Show hero if > 0.5

                } else {
                    setHeroes([]); // No active heroes
                    setShouldShowHero(false); // Don't show the section
                }
            } catch (err: any) {
                setError(err.message || "Failed to load hero data.");
                setShouldShowHero(false);
            } finally {
                setIsLoading(false);
            }
        };

        fetchHeroData();
    }, []);

    // Carousel effect: Cycle through heroes
    useEffect(() => {
        if (heroes.length > 0 && shouldShowHero) {
            const intervalId = setInterval(() => {
                setCurrentHeroIndex((prevIndex) => (prevIndex + 1) % heroes.length); // Cycle through the array
            }, 5000); // Change hero every 5 seconds

            return () => clearInterval(intervalId); // Cleanup interval on unmount or heroes change
        }
    }, [heroes, shouldShowHero]);

    if (error) {
        return <section className="bg-white py-8 antialiased dark:bg-gray-900 md:py-16">Error: {error}</section>; // Basic error display
    }

    if (!shouldShowHero && !isLoading) {
        return null; // Don't render the hero section at all
    }

    if (isLoading) {
        return null;
    }

    const heroToRender = heroes[currentHeroIndex];

    return (
        <section className="bg-white py-8 antialiased dark:bg-gray-900 md:py-16">
            <div className="mx-auto grid max-w-screen-xl px-4 pb-8 md:grid-cols-12 lg:gap-12 lg:pb-16 xl:gap-0">
                <div className="content-center justify-self-start md:col-span-7 md:text-start">
                    <h1 className="mb-4 text-4xl font-extrabold leading-none tracking-tight dark:text-white md:max-w-2xl md:text-5xl xl:text-6xl">{heroToRender?.title}</h1>
                    <p className="mb-4 max-w-2xl text-gray-500 dark:text-gray-400 md:mb-12 md:text-lg mb-3 lg:mb-5 lg:text-xl">{heroToRender?.subtitle}</p>
                    {heroToRender?.link && (
                        <Link
                            href={heroToRender.link}
                            className="inline-block rounded-lg bg-primary-700 px-6 py-3.5 text-center font-medium text-white hover:bg-primary-800 focus:outline-none focus:ring-4 focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800"
                        >
                            Shop Now
                        </Link>
                    )}
                </div>
                <div
                    className="hidden md:col-span-5 md:mt-0 md:flex md:items-center md:justify-center"
                    style={{ width: '609px', height: '421px' }}
                >
                    <Image
                        src={heroToRender?.image}
                        alt="Hero Image"
                        width={609}
                        height={421}
                        className="rounded-lg"
                        style={{ objectFit: 'contain' }}
                    />
                </div>
            </div>
        </section>
    );
};

export default Hero;